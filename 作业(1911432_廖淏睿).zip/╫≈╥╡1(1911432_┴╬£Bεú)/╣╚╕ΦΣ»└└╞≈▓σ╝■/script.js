alert("你该去学习互联网数据库开发了");
document.getElementById("kw").value="PHP从入门到入土";